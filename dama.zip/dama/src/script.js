let clickedIdsW=[];
let clickedIdsB=[];
let clickedIdsWK=[];
let clickedIdsBK=[];
let isBlack=false;
let isWhite=false;
let isBKing=false;
let isWKing=false;
let isRemoved=false;
let lastReportedState = {"white": [], "black":[], "whiteKing": [], "blackKing": []};

function blackTrue() {
  isBlack=true;
  isWhite=false;
  isBKing=false;
  isWKing=false;
}

function whiteTrue() {
  isWhite=true;
  isBlack=false;
  isBKing=false;
  isWKing=false;
}

function bKingTrue() {
  isBKing=true;
  isBlack=false;
  isWhite=false;
  isWKing=false;
}

function wKingTrue() {
  isWKing=true;
  isBlack=false;
  isWhite=false;
  isBKing=false;
}

function removeTrue() {
  isWKing=false;
  isBlack=false;
  isWhite=false;
  isBKing=false;
  isRemoved=true;
}

function removeItemW(clicked_id) { 
  var index = clickedIdsW.indexOf(clicked_id);
  if (index > -1) {
    clickedIdsW.splice(index, 1);
  }
  return clickedIdsW;
}      

function removeItemB(clicked_id) { 
   var index = clickedIdsB.indexOf(clicked_id);
   if (index > -1) {
     clickedIdsB.splice(index, 1);
   }
   return clickedIdsB;
}

function removeItemWK(clicked_id) { 
   var index = clickedIdsWK.indexOf(clicked_id);
   if (index > -1) {
     clickedIdsWK.splice(index, 1);
   }
   return clickedIdsWK;
}
      
function removeItemBK(clicked_id) { 
   var index = clickedIdsBK.indexOf(clicked_id);
   if (index > -1) {
     clickedIdsBK.splice(index, 1);
   }
   return clickedIdsBK;
}   
      
 function reply_click(clicked_id) { 
  if(isBlack==true) {
    clickedIdsB.unshift(clicked_id);
    document.getElementById(clicked_id).style.background="black";
    console.log(clickedIdsB);
  } else if(isWhite==true) {
    clickedIdsW.unshift(clicked_id);
    document.getElementById(clicked_id).style.background="white";
    console.log(clickedIdsW);
  } else if(isWKing==true) {
    clickedIdsWK.unshift(clicked_id);
    document.getElementById(clicked_id).style.background="yellow";
    console.log(clickedIdsWK);
  } else if(isBKing==true) {
    clickedIdsBK.unshift(clicked_id);
    document.getElementById(clicked_id).style.background="blue";
    console.log(clickedIdsBK);
  } else if(isRemoved==true) {
     clickedIdsW = removeItemW(clicked_id);
     clickedIdsB = removeItemB(clicked_id);
     clickedIdsWK = removeItemWK(clicked_id);
     clickedIdsBK = removeItemBK(clicked_id);
     document.getElementById(clicked_id).style.background="#BA7A3A";
  }
   
   // Create a JSON variable that describes currently clicked fields
   // on client.
   console.log("Currently clicked Ids by color");
   console.log(clickedIdsW);
   console.log(clickedIdsB);
   console.log(clickedIdsWK);
   console.log(clickedIdsBK);
   
   let stav = {
     "white": clickedIdsW,
     "black": clickedIdsB,
     "whiteKing": clickedIdsWK,
     "blackKing": clickedIdsBK
   }
   console.log("odesilam")
   console.log(stav);
   lastReportedState = stav;
   potvrdSvujTah(stav);
   
}   
  
/*function aktualizujPozici() { 
  let getMove = new XMLHttpRequest();
  getMove.open("GET", "https://danieldusek.com/.security-tests/73700172-10b1-422f-93b8-1476d0581f4b/load.php?type=dama-dan");
  getMove.send();
  getMove.onload = function(){ 
                            };
}

aktualizujPozici();*/

function potvrdSvujTah(stav) { 
  let sendMove = new XMLHttpRequest();
  sendMove.open("POST", "https://danieldusek.com/.security-tests/73700172-10b1-422f-93b8-1476d0581f4b/store.php", true);
  sendMove.setRequestHeader("Content-type", "application/x-www-form-urlencoded");
  sendMove.send("data=" + JSON.stringify(stav) + "&type=dama-dan");
}



/*clickedIdsBK=["a1","a5","b4"];
clickedIdsWK=["a3","c7","h6"];
clickedIdsW=["g5","c3","g7"];
clickedIdsB=["b8","d6","f4"];*/

var polickaNaDesce= ["a1","a3","a5","a7","b2","b4","b6","b8",
                    "c1","c3","c5","c7","d2","d4","d6","d8",
                    "e1","e3","e5","e7","f2","f4","f6","f8",
                    "g1","g3","g5","g7","h2","h4","h6","h8"];

   
function postavPozici(fields){ 
  for (let i = 0; i < fields.length; i++) {
    if (clickedIdsW.indexOf(fields[i])!==-1) {
      document.getElementById(fields[i]).style.background="white";
    } else if (clickedIdsB.indexOf(fields[i])!==-1) {
      document.getElementById(fields[i]).style.background="black";
    } else if (clickedIdsBK.indexOf(fields[i])!==-1) {
      document.getElementById(fields[i]).style.background="blue";
    } else if (clickedIdsWK.indexOf(fields[i])!==-1) {
      document.getElementById(fields[i]).style.background="yellow";
    } else {
      document.getElementById(fields[i]).style.background="#BA7A3A";
    }
  }
}
//postavPozici(polickaNaDesce);


// In regular intervals check whether there are new
setInterval(() => {
  // Poll the remote server for updates
  // on updates, redraw the fields.
  let getMove = new XMLHttpRequest();
  getMove.open("GET", "https://danieldusek.com/.security-tests/73700172-10b1-422f-93b8-1476d0581f4b/load.php?type=dama-dan");
  getMove.setRequestHeader('cache-control', 'no-cache, must-revalidate, post-check=0, pre-check=0');
  getMove.setRequestHeader('cache-control', 'max-age=0');
  getMove.setRequestHeader('expires', '0');
  getMove.setRequestHeader('expires', 'Tue, 01 Jan 1980 1:00:00 GMT');
  getMove.setRequestHeader('pragma', 'no-cache')
  
  getMove.onload = function (event) {
    let response = getMove.response;
    console.log("Resposnse received");
    console.log(JSON.parse(getMove.response));
    
    // Compare the lastReportedState with received response
    // the easiest way is to convert both last reported and
    // received to strings and compare them as strings.
    if (response === JSON.stringify(lastReportedState)) {
      // No need for update.
    } else {
      console.log("I will need to redraw the fields with " + response);
      let parsedData = JSON.parse(response);
      clickedIdsW = parsedData["white"];
      clickedIdsWK = parsedData["whiteKing"];
      clickedIdsB = parsedData["black"];
      clickedIdsBK = parsedData["blackKing"];
      console.log("Prekreslim datama ");
      console.log(parsedData);
      postavPozici(polickaNaDesce);
      lastReportedState = parsedData;
    }
    
    
  };
  
  getMove.send(); 
}, 2000);