var obrazkyA = ["Pes", "Tulipan", "Auto","Ruze","Krajina","Pohar" ];
var obrazkyB = ["Pes", "Tulipan", "Auto","Ruze","Krajina","Pohar"];
var srovnej=[1,2];
var count=0;




function shuffle(obrazkyA) {
  var currentIndex = obrazkyA.length, temporaryValue, randomIndex;

  // While there remain elements to shuffle...
  while (0 !== currentIndex) {

    // Pick a remaining element...
    randomIndex = Math.floor(Math.random() * currentIndex);
    currentIndex -= 1;

    // And swap it with the current element.
    temporaryValue = obrazkyA[currentIndex];
    obrazkyA[currentIndex] = obrazkyA[randomIndex];
    obrazkyA[randomIndex] = temporaryValue;
  }

  return obrazkyA;
}

shuffle(obrazkyA);

function shuffle(obrazkyB) {
  var currentIndex = obrazkyB.length, temporaryValue, randomIndex;

  // While there remain elements to shuffle...
  while (0 !== currentIndex) {

    // Pick a remaining element...
    randomIndex = Math.floor(Math.random() * currentIndex);
    currentIndex -= 1;

    // And swap it with the current element.
    temporaryValue = obrazkyB[currentIndex];
    obrazkyB[currentIndex] = obrazkyB[randomIndex];
    obrazkyB[randomIndex] = temporaryValue;
  }

  return obrazkyB;
}

shuffle(obrazkyB);







function pocitejPary ()
{if (prvniKarticka==druhaKarticka)
{ document.getElementById("pary").textContent ="k";}};


var clickedIds=[]
var pocetBodu=0
var pocetPokusu=0

 function reply_click(clicked_id)
  {  clickedIds.unshift(clicked_id);
    console.log(clickedIds);
    if(srovnej[0]==srovnej[1])
      {document.getElementById(clickedIds[0]).style.background="white";
      document.getElementById(clickedIds[1]).style.background="white";
      pocetBodu++;}
  pocetPokusu=pocetPokusu+0.5;
   
   document.getElementById("body").textContent="Počet bodů: " + pocetBodu;
document.getElementById("pokusy").textContent="Počet pokusů: " + pocetPokusu;
  
  }



function onclicked(){if(srovnej[0]==srovnej[1])
                 {console.log(srovnej[0],srovnej[1]); 
                 }};


function otoc(){
  count=count+1;
  document.getElementById("pocet").textContent=count;
  onclicked()
  
};


function nulujVse(){  

 if (count>1)
{document.getElementById("a1").textContent="  ";
document.getElementById("a2").textContent=" ";
 document.getElementById("a3").textContent=" ";
 document.getElementById("a4").textContent=" ";
 document.getElementById("a5").textContent=" ";
 document.getElementById("a6").textContent=" ";
 document.getElementById("b1").textContent=" ";
 document.getElementById("b2").textContent=" ";
 document.getElementById("b3").textContent=" ";
 document.getElementById("b4").textContent=" ";
 document.getElementById("b5").textContent=" ";
 document.getElementById("b6").textContent=" ";
 count=0;
 srovnej=[1,2];
 clickedIds=[];
}};






function check(){document.getElementById("srov").textContent=srovnej;
                 
                 if(srovnej[0]==srovnej[1])
                 {console.log(srovnej[0],srovnej[1]); 
                 }
                };
                                           


function otocKarticku1()
{ nulujVse();
document.getElementById("a1").textContent =obrazkyA[0];
  srovnej.unshift(obrazkyA[0])
check();

};


function otocKarticku2(){
  nulujVse();
  document.getElementById("b1").textContent =obrazkyB[0];
  
 srovnej.unshift(obrazkyB[0])
      
check();};



function otocKarticku3(){
  nulujVse();
  document.getElementById("a2").textContent =obrazkyA[1];
 
   srovnej.unshift(obrazkyA[1]);check();

      ;};

function otocKarticku4(){
  nulujVse();
document.getElementById("b2").textContent =obrazkyB[1];
  
   srovnej.unshift(obrazkyB[1])
  
  check();}


function otocKarticku5(){
  nulujVse();
document.getElementById("a3").textContent =obrazkyA[2];
   srovnej.unshift(obrazkyA[2]);
  check();};

function otocKarticku6(){
  nulujVse();
  document.getElementById("b3").textContent =obrazkyB[2];
   srovnej.unshift(obrazkyB[2]);
  check();};

function otocKarticku7(){
  nulujVse();
  document.getElementById("a4").textContent =obrazkyA[3];
srovnej.unshift(obrazkyA[3]);check();};

function otocKarticku8(){
  nulujVse();
  document.getElementById("b4").textContent =obrazkyB[3];
srovnej.unshift(obrazkyB[3]);check();};

function otocKarticku9(){
  nulujVse();
  document.getElementById("a5").textContent =obrazkyA[4];
srovnej.unshift(obrazkyA[4]);check();};

function otocKarticku10(){
  nulujVse();
  document.getElementById("b5").textContent =obrazkyB[4];
srovnej.unshift(obrazkyB[4]);check();};

function otocKarticku11(){
  nulujVse();
  document.getElementById("a6").textContent =obrazkyA[5];
srovnej.unshift(obrazkyA[5]);check();};

function otocKarticku12(){
  nulujVse();
  document.getElementById("b6").textContent =obrazkyB[5];
srovnej.unshift(obrazkyB[5]);check();};






           